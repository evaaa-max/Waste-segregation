# Waste segregation

A Pen created on CodePen.

Original URL: [https://codepen.io/eva-ambust/pen/gbYNOMY](https://codepen.io/eva-ambust/pen/gbYNOMY).

